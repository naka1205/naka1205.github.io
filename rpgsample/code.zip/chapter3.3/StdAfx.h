#ifdef	_MSC_VER
// ����Ŀ���
#pragma warning(disable: 4201)
#pragma warning(disable: 4100)
#pragma warning(disable: 4786)
#endif

#include <WinLib.h>

#ifdef	_DEBUG
#define	new DEBUG_NEW
#endif
