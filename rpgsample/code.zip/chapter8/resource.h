//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ParamEdit.rc
//
#define IDD_PARAMEDIT_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDD_ADD                         129
#define IDC_LEVEL                       1001
#define IDC_MOVEDIST                    1002
#define IDC_ATTACKDIST                  1003
#define IDC_ATTACK                      1004
#define IDC_MAGICPOWER                  1005
#define IDC_DEFENCE                     1006
#define IDC_RESISTANCE                  1007
#define IDC_HP                          1008
#define IDC_MP                          1009
#define IDC_ADD                         1011
#define IDC_NAME                        1013
#define IDC_NAMEEDIT                    1014
#define IDC_SET                         1015
#define IDC_MAGIC                       1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
