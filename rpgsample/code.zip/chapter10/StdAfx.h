#ifdef	_MSC_VER
// ����Ŀ���
#pragma warning(disable: 4201)
#pragma warning(disable: 4100)
#pragma warning(disable: 4786)
#endif

#include <string>
#include <vector>
#include <list>
#include <map>
#include <set>
#include <algorithm>
#include <functional>
using namespace std;

#include <WinLib.h>
#include <MMSystem.h>
#include "Config.h"

#pragma comment(lib, "winmm.lib")

#ifdef	_DEBUG
#define	new DEBUG_NEW
#endif
