//
//	Config
//
//		Copyright (c) 2000-2001 Chihiro.SAKAMOTO (HyperWorks)
//
#ifndef	__config_h__
#define	__config_h__

#define	CompanyName		"HyperWorks"
#define	ApplicationName		"RPGSYSTEM"
#define	ApplicationTitle	"RPGSAMPLE"

#define	WindowWidth		640
#define	WindowHeight	480

#define	CGPATH			"cgdata/"

#endif
